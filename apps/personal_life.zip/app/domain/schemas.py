from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


CaptureType = Literal["note", "expense", "idea", "journal", "routine", "task"]
TaskStatus = Literal["open", "done"]
RoutineStatus = Literal["pending", "done", "skipped"]
ReminderStatus = Literal["scheduled", "sent", "dismissed"]
ConversationRole = Literal["user", "assistant"]


class QuickCaptureCreate(BaseModel):
    capture_type: CaptureType = Field(
        default="note",
        description="Category of the captured item.",
    )
    content: str = Field(min_length=1, max_length=2000)
    source: str = Field(default="manual", max_length=100)


class QuickCaptureResponse(BaseModel):
    id: int
    capture_type: CaptureType
    content: str
    source: str
    created_at: datetime


class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    details: str = Field(default="", max_length=2000)
    due_date: str | None = Field(
        default=None,
        description="Optional due date in YYYY-MM-DD format.",
    )
    priority: int = Field(default=2, ge=1, le=3)


class TaskResponse(BaseModel):
    id: int
    title: str
    details: str
    due_date: str | None
    priority: int
    status: TaskStatus
    created_at: datetime
    completed_at: datetime | None


class ScheduleCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    details: str = Field(default="", max_length=2000)
    scheduled_for: str = Field(
        description="Schedule date in YYYY-MM-DD format.",
    )
    start_time: str | None = Field(
        default=None,
        description="Optional start time in HH:MM format.",
    )


class ScheduleResponse(BaseModel):
    id: int
    title: str
    details: str
    scheduled_for: str
    start_time: str | None
    created_at: datetime


class RoutineCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=2000)
    frequency: str = Field(default="daily", max_length=50)


class RoutineResponse(BaseModel):
    id: int
    name: str
    description: str
    frequency: str
    is_active: bool
    created_at: datetime


class RoutineCheckinResponse(BaseModel):
    id: int
    routine_id: int
    routine_name: str
    checkin_date: str
    status: RoutineStatus
    created_at: datetime


class NaturalCommandCreate(BaseModel):
    text: str = Field(min_length=1, max_length=500)


class NaturalCommandResponse(BaseModel):
    text: str
    interpreted_as: Literal["task", "schedule", "capture", "answer"]
    summary: str
    created_id: int
    created_type: str
    reminder_id: int | None = None


class AssistantStatusResponse(BaseModel):
    ai_enabled: bool
    mode: Literal["openai", "fallback"]
    model: str | None


class ProfileMemoryRecord(BaseModel):
    id: int
    category: str
    memory_key: str
    value_text: str
    value_type: str
    confidence: str
    memory_kind: str
    source: str
    created_at: datetime
    updated_at: datetime


class ProfileMemoryImportRequest(BaseModel):
    yaml_text: str = Field(min_length=1)


class ProfileMemoryImportResponse(BaseModel):
    imported_count: int
    categories: list[str]
    message: str


class BriefingInsight(BaseModel):
    title: str
    body: str


class AssistantOpinion(BaseModel):
    title: str
    body: str
    reason: str


class ReminderResponse(BaseModel):
    id: int
    title: str
    details: str
    remind_on: str
    remind_time: str | None
    status: ReminderStatus
    origin_type: str
    origin_id: int | None
    created_at: datetime
    notified_at: datetime | None


class ConversationMessageResponse(BaseModel):
    id: int
    role: ConversationRole
    message: str
    interpreted_as: str | None
    created_type: str | None
    created_at: datetime


class BriefingDigestResponse(BaseModel):
    period: Literal["morning", "evening"]
    headline: str
    bullets: list[str]


class BriefingResponse(BaseModel):
    today: str
    open_task_count: int
    completed_today_count: int
    capture_count_today: int
    schedule_count_today: int
    completed_routine_count: int
    total_routine_count: int
    top_tasks: list[TaskResponse]
    schedules: list[ScheduleResponse]
    routine_checkins: list[RoutineCheckinResponse]
    message: str
    insights: list[BriefingInsight]
    opinions: list[AssistantOpinion]
